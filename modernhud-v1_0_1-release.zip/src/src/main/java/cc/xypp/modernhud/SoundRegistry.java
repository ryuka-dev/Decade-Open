package cc.xypp.modernhud;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class SoundRegistry {

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, ModernHud.MOD_ID);

    /** Played (locally, only to attacker + victim) when Absorption is fully depleted. */
    public static final RegistryObject<SoundEvent> ABSORPTION_BREAK = SOUNDS.register(
            "absorption_break",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(ModernHud.MOD_ID, "absorption_break"))
    );

    /** Played (locally, only to attacker + victim) when a hit lands on active Absorption that doesn't fully break it. */
    public static final RegistryObject<SoundEvent> ARMOR_HIT = SOUNDS.register(
            "armor_hit",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(ModernHud.MOD_ID, "armor_hit"))
    );

    private SoundRegistry() {
    }
}
