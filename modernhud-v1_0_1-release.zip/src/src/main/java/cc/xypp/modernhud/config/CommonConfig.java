package cc.xypp.modernhud.config;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.config.ModConfigEvent;

/**
 * Common configuration - runs on the server (and the integrated singleplayer
 * server). Controls whether "hit landed on active Absorption" and
 * "Absorption fully depleted" events are detected/sent at all.
 *
 * Deliberately does NOT have a "broadcast to everyone nearby" option - by
 * design, only the attacker and the victim are ever notified, so there is
 * nothing here to configure about who else can hear it.
 */
@Mod.EventBusSubscriber(modid = "modernhud", bus = Mod.EventBusSubscriber.Bus.MOD)
public class CommonConfig {

    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();

    private static final ForgeConfigSpec.BooleanValue ENABLE_HIT_FEEDBACK;
    private static final ForgeConfigSpec.BooleanValue ENABLE_BREAK_FEEDBACK;
    private static final ForgeConfigSpec.BooleanValue CLEAR_ABSORPTION_ON_EFFECT_END;

    public static final ForgeConfigSpec SPEC;

    public static boolean enableHitFeedback;
    public static boolean enableBreakFeedback;
    public static boolean clearAbsorptionOnEffectEnd;

    static {
        BUILDER.comment(
                "Server-side detection of Absorption being hit/depleted.",
                "Only ever notifies the attacker and the victim directly - never anyone else nearby.")
                .push("shieldFeedback");

        ENABLE_HIT_FEEDBACK = BUILDER
                .comment("When a hit lands on an entity's active Absorption without fully depleting it,",
                        "notify the attacker and the victim (sound only) so both know the shield held.")
                .translation("modernhud.config.enable_hit_feedback")
                .define("enableHitFeedback", true);

        ENABLE_BREAK_FEEDBACK = BUILDER
                .comment("When a hit (or the effect running out) fully depletes an entity's Absorption,",
                        "notify the attacker (sound + icon, see client config for where it shows) and the victim (sound only).")
                .translation("modernhud.config.enable_break_feedback")
                .define("enableBreakFeedback", true);

        CLEAR_ABSORPTION_ON_EFFECT_END = BUILDER
                .comment("Vanilla quirk: normally, when the Absorption effect ends (its timer runs out, or",
                        "it's removed by /effect clear, a milk bucket, etc.), the leftover absorption HEARTS",
                        "are NOT reset - they silently stick around and only go away once enough damage",
                        "consumes them. That makes the HUD bar look 'stuck' after clearing the effect.",
                        "With this on, ending the Absorption effect (any way) also zeroes the entity's",
                        "absorption points immediately, so the HUD (and the actual shield) both clear",
                        "together. This is a deliberate small gameplay change from vanilla; turn it off",
                        "to restore the original vanilla behaviour.")
                .translation("modernhud.config.clear_absorption_on_effect_end")
                .define("clearAbsorptionOnEffectEnd", true);

        BUILDER.pop();

        SPEC = BUILDER.build();
    }

    @SubscribeEvent
    static void onLoad(final ModConfigEvent event) {
        enableHitFeedback = ENABLE_HIT_FEEDBACK.get();
        enableBreakFeedback = ENABLE_BREAK_FEEDBACK.get();
        clearAbsorptionOnEffectEnd = CLEAR_ABSORPTION_ON_EFFECT_END.get();
    }
}
